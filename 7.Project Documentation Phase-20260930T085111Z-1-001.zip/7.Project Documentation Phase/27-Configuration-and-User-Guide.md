# Configuration and User Guide

## Requester guide
1. Open the Service Catalog.
2. Select **Standard Laptop Order**.
3. Enter the required information.
4. Submit the request.
5. Track the request using the ServiceNow request information.
6. Respond to any approval or clarification requirement.
7. Review the final status.

## Administrator guide
1. Verify the catalog item.
2. Verify the Flow Designer flow is active.
3. Verify assignment configuration.
4. Verify required notifications.
5. Review flow execution details when troubleshooting.
6. Review catalog tasks and request records for traceability.

## Troubleshooting checklist
- Confirm the flow is active.
- Confirm the catalog item triggers the expected flow.
- Confirm required fields are populated.
- Confirm the assignment group is valid.
- Review flow execution details.
- Review the generated catalog task.
