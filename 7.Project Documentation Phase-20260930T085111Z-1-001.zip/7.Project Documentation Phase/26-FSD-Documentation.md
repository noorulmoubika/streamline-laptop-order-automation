# Functional Specification Document (FSD)

## Document purpose
Define the functional behavior of the Standard Laptop Order automation.

## Actors
- Requester
- Approver/Validator
- Procurement Team
- ServiceNow Administrator

## Input
Standard laptop request submitted through the Service Catalog.

## Processing
The Flow Designer workflow processes the request, performs the configured approval/validation, creates and assigns procurement work, and handles subsequent status/notification actions.

## Output
A traceable procurement task and a completed/updated request according to the configured workflow.

## Business rules
- Required request information must be supplied.
- The request must follow the configured approval/validation path.
- Procurement work must be assigned to the responsible team.
- Completion must be recorded in ServiceNow.
