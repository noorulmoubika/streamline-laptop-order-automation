# Phase 7 — Final Project Report

## 1. Title
**Streamlining IT Procurement: Automating Standard Laptop Orders with Flow Designer**

## 2. Introduction
The project uses ServiceNow Service Catalog and Flow Designer to structure and automate a standard laptop procurement process.

## 3. Problem
Manual procurement coordination can involve repetitive data collection, routing, task creation, and follow-up.

## 4. Proposed solution
A standardized Service Catalog item initiates an automated fulfillment flow.

## 5. Technologies
- ServiceNow
- Service Catalog
- Flow Designer
- Automation

## 6. Workflow
User → Catalog request → Flow → Approval/validation → Procurement task → Completion/notification.

## 7. Testing
Functional, performance, and user acceptance testing are planned and documented in Phase 6.

## 8. Outcome
The configured solution is intended to standardize the request process, reduce manual coordination, and improve request traceability.

## 9. Conclusion
The project demonstrates how ServiceNow automation can be applied to a common IT procurement process.

> Add actual screenshots, test results, dates, and instance-specific details before final submission.
