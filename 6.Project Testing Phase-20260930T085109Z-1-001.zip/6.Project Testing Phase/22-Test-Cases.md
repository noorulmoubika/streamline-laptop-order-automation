# Test Cases

| ID | Test case | Expected result | Status |
|---|---|---|---|
| TC-01 | Open Standard Laptop catalog item | Item opens successfully | Not Run |
| TC-02 | Submit request with valid mandatory data | Request is created | Not Run |
| TC-03 | Submit request with missing mandatory data | Submission is prevented/validation shown | Not Run |
| TC-04 | Verify flow trigger | Flow starts for a valid request | Not Run |
| TC-05 | Verify approval/validation | Configured approval/validation executes | Not Run |
| TC-06 | Verify catalog task creation | Procurement task is created | Not Run |
| TC-07 | Verify assignment | Task reaches configured procurement group | Not Run |
| TC-08 | Complete procurement task | Task moves to configured completed state | Not Run |
| TC-09 | Verify request progression | Parent request progresses correctly | Not Run |
| TC-10 | Verify notification | Configured recipient receives notification | Not Run |
