# Phase 6 — Test Plan

## Testing objectives
Verify that the Standard Laptop Order catalog item and Flow Designer automation work as intended.

## Test levels
1. Functional testing
2. Flow/process testing
3. Performance testing
4. User Acceptance Testing (UAT)

## Entry criteria
- Catalog item configured.
- Flow activated.
- Required assignment configuration available.
- Test user/request data available.

## Exit criteria
- Critical test cases pass.
- Defects are recorded and resolved or documented.
- UAT confirms that the process meets the expected requirement.
