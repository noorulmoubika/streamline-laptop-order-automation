# Phase 3 — Problem–Solution Fit

## Problem
Standard laptop procurement contains repetitive manual coordination.

## Proposed solution
Use a ServiceNow Service Catalog item combined with Flow Designer automation.

## Fit
| Problem | Solution response |
|---|---|
| Inconsistent request information | Standard catalog form |
| Manual routing | Automated flow/task assignment |
| Manual fulfillment coordination | Catalog task creation |
| Limited status visibility | ServiceNow request/task tracking |
| Repeated communication | Configured notifications |

## Success indicators
- Standardized request submission
- Correct flow triggering
- Correct task creation and assignment
- Traceable request progress
- Successful completion of the fulfillment process
