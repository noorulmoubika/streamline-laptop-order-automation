# Flow Designer Design

## Trigger
A Standard Laptop Service Catalog request is submitted.

## Planned flow
1. Receive the catalog request.
2. Validate required request information.
3. Process the configured approval/validation step.
4. If approved/valid, create a procurement catalog task.
5. Assign the task to the configured procurement group.
6. Wait for procurement task completion.
7. Update/complete the request according to the configured process.
8. Send a notification when applicable.

## Alternate path
If the request is rejected or fails validation, follow the configured rejection/error handling path and notify the relevant user when required.
