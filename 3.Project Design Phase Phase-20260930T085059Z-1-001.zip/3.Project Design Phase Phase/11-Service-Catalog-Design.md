# Service Catalog Design

## Catalog item
**Standard Laptop Order**

## Suggested request fields
- Requested for
- Department
- Manager / approver
- Laptop requirement / justification
- Required date
- Location
- Additional comments

## Design principles
- Keep the form simple.
- Mark essential fields as mandatory.
- Use clear field labels.
- Avoid collecting unnecessary information.
- Make the fulfillment process traceable.

> Adjust the exact fields to match the TN Skills task specification and the configured ServiceNow instance.
