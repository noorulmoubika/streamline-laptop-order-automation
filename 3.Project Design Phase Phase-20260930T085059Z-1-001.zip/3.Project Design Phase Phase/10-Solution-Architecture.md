# Solution Architecture

```text
+------------------+
|      Employee    |
+--------+---------+
         |
         v
+---------------------------+
| Service Catalog Item      |
| Standard Laptop Request   |
+-------------+-------------+
              |
              v
+---------------------------+
|      Flow Designer        |
| Trigger + Actions        |
+-------------+-------------+
              |
        +-----+------+
        |            |
        v            v
+-----------+   +----------------+
| Approval/ |   | Request / Task  |
| Validation|   | Processing      |
+-----+-----+   +--------+-------+
        |                 |
        +--------+--------+
                 v
       +----------------------+
       | Procurement Team     |
       | Catalog Task         |
       +----------+-----------+
                  |
                  v
       +----------------------+
       | Completion / Notice  |
       +----------------------+
```
