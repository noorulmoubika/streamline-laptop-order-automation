# Problem Statement

Standard laptop procurement can require repeated manual activities such as collecting request information, obtaining approval, assigning procurement work, tracking progress, and communicating status.

This can result in delays, inconsistent handling, repeated data entry, and limited visibility.

## Problem statement
**How might we automate the standard laptop ordering process so that requests are captured consistently, routed to the correct team, tracked through fulfillment, and communicated to the requester?**
