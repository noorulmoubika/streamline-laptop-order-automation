# Phase 1 — Brainstorming & Idea Generation

## Project theme
Streamlining IT procurement through ServiceNow automation.

## Ideas considered
- Automate standard laptop requests.
- Create a Service Catalog item for laptop procurement.
- Route requests automatically to the procurement team.
- Generate catalog tasks from requests.
- Notify users about important status changes.
- Reduce manual follow-up and repetitive administration.

## Selected idea
**Automating Standard Laptop Orders with ServiceNow Flow Designer.**

## Expected value
The selected idea creates a repeatable process for a common IT procurement request while improving tracking and reducing manual coordination.
