# Empathy Map

## Primary user
An employee who needs a standard laptop for work.

### Says
- I need a laptop for my work.
- I want the request process to be simple.
- I want to know the status of my request.

### Thinks
- What information do I need to provide?
- Who will approve my request?
- When will procurement start?

### Does
- Opens the Service Catalog.
- Selects the standard laptop request.
- Provides the required information.
- Tracks the request.

### Feels
- Wants a predictable process.
- Wants visibility and clear communication.
- May become frustrated by manual follow-up.

## Design implication
The solution should provide a simple request form, automated routing, clear task ownership, and status communication.
