# Flow Designer Configuration

## Flow objective
Automate fulfillment after a Standard Laptop Order catalog request is submitted.

## Configuration checklist
- [ ] Create the flow.
- [ ] Configure the catalog request trigger.
- [ ] Add required approval/validation logic.
- [ ] Add catalog task creation.
- [ ] Configure task assignment.
- [ ] Add required status updates.
- [ ] Add required notifications.
- [ ] Test the flow with a sample request.
- [ ] Capture the completed flow screenshot.

## Flow name
Use a clear name such as:
**Standard Laptop Order Fulfillment**
