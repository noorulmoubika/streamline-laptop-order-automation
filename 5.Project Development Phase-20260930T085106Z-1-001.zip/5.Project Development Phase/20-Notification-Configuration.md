# Notification Configuration

## Purpose
Provide useful status communication without requiring manual follow-up.

## Potential notifications
- Request submitted
- Approval required
- Request approved/rejected
- Procurement task completed
- Request completed

## Configuration checklist
- [ ] Identify required notification events.
- [ ] Configure recipients.
- [ ] Configure useful subject/content.
- [ ] Test each notification.
- [ ] Capture evidence where applicable.
