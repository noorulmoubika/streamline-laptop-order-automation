# Phase 5 — Service Catalog Configuration

## Objective
Create the Service Catalog item required for standard laptop ordering.

## Configuration checklist
- [ ] Create/open the appropriate Service Catalog application/context.
- [ ] Create catalog item: Standard Laptop Order.
- [ ] Configure item description.
- [ ] Add required variables.
- [ ] Configure mandatory fields.
- [ ] Configure user/requester behavior.
- [ ] Validate the catalog item from the requester perspective.
- [ ] Capture a screenshot of the completed item.

## Evidence
Add screenshots to:
`Phase-05-Project-Development/screenshots/`
