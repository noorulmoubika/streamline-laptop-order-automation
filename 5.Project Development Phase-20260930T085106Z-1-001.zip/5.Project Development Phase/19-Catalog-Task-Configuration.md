# Catalog Task Configuration

## Purpose
Create a task that represents the procurement work required to fulfill the laptop request.

## Expected task information
- Request reference
- Requested-for user
- Laptop requirement
- Relevant comments
- Assignment group
- Task state
- Completion information

## Completion
The procurement team updates the catalog task according to the configured process. Completion should allow the parent request to progress to the next stage.
