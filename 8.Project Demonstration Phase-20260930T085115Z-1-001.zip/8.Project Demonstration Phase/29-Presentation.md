# Project Presentation Outline

## Slide 1 — Title
Streamlining IT Procurement: Automating Standard Laptop Orders with Flow Designer

## Slide 2 — Problem
Manual laptop procurement requires repeated coordination.

## Slide 3 — Proposed Solution
Service Catalog + Flow Designer automation.

## Slide 4 — Requirements
Standard request data, routing, task creation, tracking and notifications.

## Slide 5 — Architecture
Requester → Catalog → Flow → Approval/Validation → Procurement Task → Completion.

## Slide 6 — Development
Catalog item and Flow Designer configuration.

## Slide 7 — Testing
Functional, performance and UAT evidence.

## Slide 8 — Result
A standardized and traceable procurement workflow.

## Slide 9 — Demo
Live ServiceNow workflow demonstration.

## Slide 10 — Conclusion
Automation reduces repetitive manual coordination and provides a structured fulfillment process.
