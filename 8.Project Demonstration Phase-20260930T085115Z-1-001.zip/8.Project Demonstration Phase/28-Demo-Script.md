# Phase 8 — Project Demonstration Script

## Opening
Good morning/afternoon. Our project is **Streamlining IT Procurement: Automating Standard Laptop Orders with Flow Designer**.

## Demonstration sequence
1. Introduce the problem.
2. Open the Service Catalog.
3. Show the Standard Laptop Order item.
4. Enter sample request information.
5. Submit the request.
6. Show the request record.
7. Show the Flow Designer workflow.
8. Show the approval/validation step if applicable.
9. Show the generated catalog task.
10. Show task assignment to the procurement team.
11. Complete the task using the configured test process.
12. Show the final request/status.
13. Explain the testing evidence.
14. Summarize the outcome.

## Closing
The project demonstrates how ServiceNow Service Catalog and Flow Designer can automate a standard IT procurement workflow and make fulfillment more structured and traceable.
